import Capcha from './Capcha.vue'
export default Capcha