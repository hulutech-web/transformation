export default [
    {name: 'parkInfo', title: '停车场信息', icon: 'icon-parking-lot', component: 'parkInfo'},
    {name: 'chargingInfo', title: '充电桩信息', icon: 'icon-charging-pile', component: 'chargingInfo'},
    {name: 'systemSetting', title: '充电桩報告配置', icon: 'icon-charging-pile', component: 'systemSetting'},
]