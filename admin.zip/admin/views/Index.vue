<template>
    <div></div>
</template>

<script>
export default {
    meta: { title: "首页" },
};
</script>

<style lang="scss" scoped></style>
